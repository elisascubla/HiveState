import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:weather_icons/weather_icons.dart';

Future<bool> getIsFirstLaunch() async {
  final prefs = await SharedPreferences.getInstance();
  bool? value = prefs.getBool('isFirstLaunch');
  return value ?? true;
}

Future<bool> getIsAlreadyLogged() async {
  final prefs = await SharedPreferences.getInstance();
  bool? value = prefs.getBool('isAlreadyLogged');
  return value ?? false;
}

Color getColor(String code) {
  int parsedCode = int.parse(code);
  switch (parsedCode) {
    case 1:
      return Colors.green[600]!;
    case 3:
      return Colors.yellow[600]!;
    case 8:
      return Colors.red[600]!;
    default:
      return Colors.grey;
  }
}

Widget buildToDo(String title, String subtitle, String trailing) {
  return ListTile(
    contentPadding: EdgeInsets.zero,
    title: Row(
      spacing: 50,
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(fontSize: 16),
          ),
        ),
        Expanded(
          child: Text(
            subtitle,
            style: const TextStyle(fontSize: 16),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Expanded(
          child: Text(
            trailing,
            style: const TextStyle(fontSize: 16),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    ),
  );
}


Widget getWeatherIcon(String weather) {
  switch (weather) {
    case 'Clear':
      return const Icon(WeatherIcons.day_sunny, size: 40);
    case 'Clouds':
      return const Icon(WeatherIcons.cloudy, size: 40);
    case 'Rain':
      return const Icon(WeatherIcons.rain, size: 40);
    case 'Drizzle':
      return const Icon(WeatherIcons.showers, size: 40);
    case 'Thunderstorm':
      return const Icon(WeatherIcons.thunderstorm, size: 40);
    case 'Snow':
      return const Icon(WeatherIcons.snow, size: 40);
    case 'Mist':
    case 'Smoke':
    case 'Haze':
    case 'Dust':
    case 'Fog':
      return const Icon(WeatherIcons.fog, size: 40);
    case 'Sand':
    case 'Ash':
      return const Icon(WeatherIcons.dust, size: 40);
    case 'Squall':
      return const Icon(WeatherIcons.strong_wind, size: 40);
    case 'Tornado':
      return const Icon(WeatherIcons.tornado, size: 40);
    default:
      return const Icon(WeatherIcons.na, size: 40);
  }
}