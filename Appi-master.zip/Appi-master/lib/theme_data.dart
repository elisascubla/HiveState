import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

final themeData = ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: Colors.green, surface: Colors.white),
    textTheme: GoogleFonts.aBeeZeeTextTheme(
      ThemeData.light().textTheme.copyWith(
            displayLarge: const TextStyle(fontSize: 16),
            displayMedium: const TextStyle(fontSize: 14),
            displaySmall: const TextStyle(fontSize: 12),
            headlineLarge: const TextStyle(fontSize: 32),
            headlineMedium: const TextStyle(fontSize: 28),
            headlineSmall: const TextStyle(fontSize: 24),
            titleLarge: const TextStyle(fontSize: 20),
            titleMedium: const TextStyle(fontSize: 18),
            titleSmall: const TextStyle(fontSize: 16),
            bodyLarge: const TextStyle(fontSize: 14),
            bodyMedium: const TextStyle(fontSize: 12),
            bodySmall: const TextStyle(fontSize: 10),
            labelLarge: const TextStyle(fontSize: 14),
            labelMedium: const TextStyle(fontSize: 12),
            labelSmall: const TextStyle(fontSize: 10),
          ),
    ).apply(fontSizeFactor: 1.3),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: Colors.green[200]!,
      iconSize: 30
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
            backgroundColor: WidgetStateProperty.all<Color>(Colors.green[200]!),
            foregroundColor: WidgetStateProperty.all<Color>(Colors.black),
            textStyle: WidgetStateProperty.all(GoogleFonts.aBeeZee(fontSize: 18)))),
    navigationBarTheme: NavigationBarThemeData(height: 80, backgroundColor: Colors.green[200], labelTextStyle: WidgetStateProperty.all(GoogleFonts.aBeeZee(fontSize: 15))));
