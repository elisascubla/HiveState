import 'package:appi/screens/home_page.dart';
import 'package:flutter/material.dart';
import 'screens/first_access.dart';
import 'screens/login.dart';
import 'utils/utils.dart';

import 'theme_data.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<bool> isFirstLaunch;
  late Future<bool> isAlreadyLogged;

  @override
  void initState() {
    super.initState();
    isFirstLaunch = getIsFirstLaunch();
    isAlreadyLogged = getIsAlreadyLogged();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: themeData,
      home: FutureBuilder<bool>(
        future: isFirstLaunch,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const CircularProgressIndicator();
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          } else if (snapshot.hasData) {
            if (snapshot.data!) {
              return const FirstAccess();
            } else {
              return FutureBuilder<bool>(
                future: isAlreadyLogged,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (snapshot.hasData) {
                    if (snapshot.data!) {
                      return const HomePage();
                    } else {
                      return const Login();
                    }
                  } else {
                    return const Center(child: Text('Loading...'));
                  }
                },
              );
            }
          } else {
            return const Center(child: Text('Loading...'));
          }
        },
      ),
    );
  }
}
