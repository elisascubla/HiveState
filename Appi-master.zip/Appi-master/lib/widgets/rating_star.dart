import 'package:flutter/material.dart';

class MyRatingStar extends StatelessWidget {
  final Color color;
  final double rating;
  final ValueChanged<double> onRatingChanged;

  const MyRatingStar({
    required this.color,
    required this.rating,
    required this.onRatingChanged,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        double starValue = index + 1.0;
        return GestureDetector(
          onHorizontalDragUpdate: (details) {
            RenderBox renderBox = context.findRenderObject() as RenderBox;
            Offset localPosition = renderBox.globalToLocal(details.globalPosition);
            double newRating = (localPosition.dx / 50).clamp(0, 5);
            newRating = (newRating * 2).roundToDouble() / 2; // Truncate every 0.5

            onRatingChanged(newRating); //update ratings value
          },
          onTap: () {
            if (rating == starValue - 0.5) {
              onRatingChanged(starValue);
            } else {
              onRatingChanged(starValue - 0.5);
            }
          },
          child: Icon(
            rating >= starValue
                ? Icons.star
                : rating >= starValue - 0.5
                ? Icons.star_half
                : Icons.star,
            color: rating >= starValue - 0.5 ? color : Colors.grey,
            size: 50.0,
          ),
        );
      }),
    );
  }
}