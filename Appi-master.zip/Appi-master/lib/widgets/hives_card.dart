import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HiveCard extends StatelessWidget {
  const HiveCard({super.key, required this.id, required this.state, required this.stateDescr, required this.lastVisited});

  final String id;
  final String state;
  final String stateDescr;
  final String lastVisited;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            RichText(
                text: TextSpan(style: GoogleFonts.aBeeZee(fontSize: 18, fontWeight: FontWeight.bold), children: [
              TextSpan(
                text: 'Hive $id',
                style: const TextStyle(color: Colors.black),
              ),
            ])),
            Row(children: [
              const Text('current state: '),
              Container(
                width: 35,
                height: 35,
                decoration: BoxDecoration(
                  color: id == '1' ? Colors.red[200]! : Colors.green[200]!,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  state,
                ),
              ),
            ]),
          ]),
          Column(mainAxisAlignment: MainAxisAlignment.end, mainAxisSize: MainAxisSize.max, children: [
            PopupMenuButton<String>(
              onSelected: (String value) {},
              itemBuilder: (BuildContext context) => [
                PopupMenuItem(
                  value: 'Activity',
                  child: TextButton.icon(onPressed: () {}, icon: const Icon(Icons.remove_red_eye_outlined), label: const Text('Activity')),
                ),
                PopupMenuItem(
                  value: 'History',
                  child: TextButton.icon(onPressed: () {}, icon: const Icon(Icons.trending_up), label: const Text('History')),
                ),
                PopupMenuItem(
                  value: 'Thingspeak',
                  child: TextButton.icon(onPressed: () {}, icon: const Icon(Icons.wifi), label: const Text('Thingspeak')),
                ),
                PopupMenuItem(
                  value: 'Delete',
                  child: TextButton.icon(onPressed: () {}, icon: const Icon(Icons.delete), label: const Text('Delete hive')),
                ),
              ],
              icon: const Icon(Icons.more_vert),
            ),
          ]),
        ]),
        subtitle: Text('last visited: $lastVisited'),
      ),
    );
  }
}
