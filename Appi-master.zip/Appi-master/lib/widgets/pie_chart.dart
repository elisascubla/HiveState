import 'package:appi/utils/utils.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MyPieChart extends StatefulWidget {
  const MyPieChart({super.key});

  @override
  State<StatefulWidget> createState() => MyPieChartState();
}

class MyPieChartState extends State {
  int touchedIndex = -1;
  final List<String> _states = <String>['Normal', 'Low CO2', 'Hibernating'];

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Center(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          height: MediaQuery.of(context).size.width * 0.45,
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: PieChart(
                  PieChartData(
                    startDegreeOffset: 180,
                    borderData: FlBorderData(show: false),
                    sectionsSpace: 1,
                    centerSpaceRadius: 0,
                    sections: showingSections(),
                  ),
                ),
              ),
              Expanded(
                  flex: 3,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Text('States', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('45% - ${_states[0]}'),
                    Text('30% - ${_states[1]}'),
                    Text('25% - ${_states[2]}'),
                  ]))
            ],
          ),
        ),
      ),
    ]);
  }

  List<PieChartSectionData> showingSections() {
    return List.generate(3, (i) {
      final isTouched = i == touchedIndex;
      final radius = isTouched ? 85.0 : 75.0;
      switch (i) {
        case 0:
          return PieChartSectionData(
            color: getColor('1'),
            value: 45,
            title: '45%',
            radius: radius,
            titleStyle: GoogleFonts.aBeeZee(
              fontWeight: FontWeight.bold,
            ),
          );
        case 1:
          return PieChartSectionData(
            color: getColor('8'),
            value: 30,
            title: '30%',
            radius: radius,
            titleStyle: GoogleFonts.aBeeZee(
              fontWeight: FontWeight.bold,
            ),
          );
        case 2:
          return PieChartSectionData(
            color: getColor('3'),
            value: 25,
            title: '25%',
            radius: radius,
            titleStyle: GoogleFonts.aBeeZee(
              fontWeight: FontWeight.bold,
            ),
          );
        default:
          throw Error();
      }
    });
  }
}
