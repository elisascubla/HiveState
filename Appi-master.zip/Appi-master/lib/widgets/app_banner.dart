import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppBanner extends StatelessWidget {
  const AppBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
          alignment: Alignment.topCenter,
          child: Column(children: [
            Container(
              padding: const EdgeInsets.only(left: 20, right: 10),
              height: 120,
              color: Colors.green[100],
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: [
                RichText(
                  text: TextSpan(
                    style: GoogleFonts.aBeeZee(
                      fontSize: 50,
                      fontWeight: FontWeight.bold,
                    ),
                    children: const [
                      TextSpan(
                        text: 'App',
                        style: TextStyle(color: Colors.black),
                      ),
                      TextSpan(
                        text: 'i',
                        style: TextStyle(color: Colors.amber),
                      ),
                    ],
                  ),
                ),
                const Image(image: AssetImage('assets/image.png')),
              ]),
            ),
            Container(
              padding: const EdgeInsets.only(right: 20),
              height: 40,
              color: Colors.green[600],
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  RichText(
                    text: TextSpan(
                      style: GoogleFonts.aBeeZee(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                      children: const [
                        TextSpan(
                          text: 'App',
                          style: TextStyle(color: Colors.black),
                        ),
                        TextSpan(
                          text: 'i',
                          style: TextStyle(color: Colors.amber),
                        ),
                        TextSpan(
                          text: ' Hive',
                          style: TextStyle(color: Colors.amber),
                        ),
                        TextSpan(
                          text: ', happy',
                          style: TextStyle(color: Colors.black),
                        ),
                        TextSpan(
                          text: ' life',
                          style: TextStyle(color: Colors.amber),
                        ),
                        TextSpan(
                          text: '!',
                          style: TextStyle(color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ])),
    );
  }
}
