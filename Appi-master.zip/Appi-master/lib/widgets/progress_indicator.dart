import 'package:flutter/material.dart';

class MyProgressIndicator extends StatelessWidget {
  const MyProgressIndicator({required this.percentage, required this.color, this.label='', super.key});

  final String percentage;
  final String label;
  final Color color;

  double toDouble(String str){
    return double.tryParse(str.replaceAll('%', ''))! / 100;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            LinearProgressIndicator(
              value: toDouble(percentage),
              minHeight: 40,
              backgroundColor: Colors.white,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
            label == '' ?
            Text(
              percentage,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            )
            : Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('$label:', style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),), Text(' $percentage', style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),)])
          ],
        ),
      ),
    );
  }
}
