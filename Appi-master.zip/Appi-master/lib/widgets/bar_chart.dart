import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../screens/apiary_details.dart';

class MyBarChart extends StatefulWidget {
  const MyBarChart({required this.groupData, required this.apiaryId, super.key});

  final List<BarChartGroupData> groupData;
  final String apiaryId;

  @override
  State<MyBarChart> createState() => _MyBarChartState();
}

class _MyBarChartState extends State<MyBarChart> {
  bool isNavigating = false;

  void _onBarTap(BuildContext context, String apiaryId) {
    if (!isNavigating) {
      setState(() {
        isNavigating = true;
      });
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ApiaryDetails(id: apiaryId),
        ),
      ).then((_) {
        setState(() {
          isNavigating = false;
        });
      });
    }
  }

  SideTitleWidget _getLabel(TitleMeta meta, String label) {
    return SideTitleWidget(
        meta: meta,
        space: 10,
        child: Text(
          label,
          style: const TextStyle(fontSize: 14),
        ));
  }

  AxisTitles _getBottomTitles() {
    return AxisTitles(
      sideTitles: SideTitles(
        reservedSize: 70,
        showTitles: true,
        getTitlesWidget: (double value, TitleMeta meta) {
          switch (value.toInt()) {
            case 0:
              return _getLabel(meta, 'Normal');
            case 1:
              return _getLabel(meta, 'Fanning');
            case 2:
              return _getLabel(meta, 'Low CO2');
            case 3:
              return _getLabel(meta, 'Predator');
            default:
              return const SizedBox.shrink();
          }
        },
      ),
    );
  }

  AxisTitles _getRightTitles(int index, int lastIndex) {
    return AxisTitles(
        sideTitles: SideTitles(
      interval: 0.5,
      showTitles: index == lastIndex,
      getTitlesWidget: (double value, TitleMeta meta) {
        if (value >= 0 && value < 0.5) {
          return const RotatedBox(
              quarterTurns: 3,
              child: Text(
                '0',
                style: TextStyle(fontSize: 18),
              ));
        }
        if (value >= 0.5 && value < 1.0) return const RotatedBox(quarterTurns: 3, child: Text('2', style: TextStyle(fontSize: 18)));
        if (value >= 1.0 && value < 1.5) return const RotatedBox(quarterTurns: 3, child: Text('4', style: TextStyle(fontSize: 18)));
        if (value >= 1.5 && value < 2.0) return const RotatedBox(quarterTurns: 3, child: Text('6', style: TextStyle(fontSize: 18)));
        return const Text('');
      },
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 70,
      child: ListView.builder(
        itemCount: widget.groupData.length,
        itemBuilder: (context, index) {
          final groupData = widget.groupData[index];

          return Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: SizedBox(
                  height: 70,
                  child: BarChart(
                    BarChartData(
                      maxY: 2,
                      barGroups: [groupData],
                      barTouchData: BarTouchData(
                        touchTooltipData: BarTouchTooltipData(
                          getTooltipItem: (group, groupIndex, rod, rodIndex) {
                            return null;
                          },
                        ),
                      ),
                      rotationQuarterTurns: 1,
                      alignment: BarChartAlignment.center,
                      gridData: const FlGridData(show: false),
                      titlesData: FlTitlesData(
                        show: true,
                        leftTitles: const AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: false,
                          ),
                        ),
                        topTitles: const AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: false,
                          ),
                        ),
                        rightTitles: _getRightTitles(index, widget.groupData.length - 1),
                        bottomTitles: _getBottomTitles(),
                      ),
                      borderData: FlBorderData(show: false),
                    ),
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  _onBarTap(context, widget.apiaryId);
                },
                icon: const Icon(Icons.info_outline),
              ),
            ],
          );
        },
      ),
    );
  }
}
