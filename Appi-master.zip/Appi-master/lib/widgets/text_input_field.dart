import 'package:flutter/material.dart';

class TextInputField extends StatelessWidget {
  const TextInputField({required this.labelText, required this.icon, required this.controller, required this.validator, this.isRequired = true, this.obscureText = false, this.hintText = '', super.key});

  final String labelText;
  final Widget icon;
  final TextEditingController controller;
  final FormFieldValidator<String> validator;
  final bool isRequired;
  final bool obscureText;
  final String hintText;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onTapOutside: (event) {
        FocusScope.of(context).unfocus();
      },
      controller: controller,
      decoration: InputDecoration(
        helperText: isRequired ? '*required' : '',
        prefixIcon: icon,
        labelText: labelText,
        hintText: hintText,
        border: const OutlineInputBorder(),
      ),
      obscureText: obscureText,
      validator: (value) {
        return validator(value);
      },
    );
  }
}

