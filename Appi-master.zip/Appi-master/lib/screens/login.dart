import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/app_banner.dart';
import '../widgets/text_input_field.dart';
import 'home_page.dart';
import 'sign_on.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _rememberMe = true;

  Future<void> saveIsAlreadyLogged() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isAlreadyLogged', _rememberMe);
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        children: [
          const AppBanner(),
          const SizedBox(height: 30.0),
          Column(
            children: [
              const Text(
                'WELCOME!',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const Text(
                'Enter your credentials',
                style: TextStyle(fontSize: 20),
              ),
              const SizedBox(height: 30.0),
              Form(
                key: _formKey,
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  shrinkWrap: true,
                  children: [
                    TextInputField(
                      controller: _usernameController,
                      icon: const Icon(Icons.person),
                      labelText: 'Username or e-mail',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a username or an e-mail';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 30.0),
                    TextInputField(
                      controller: _passwordController,
                      icon: const Icon(Icons.lock),
                      labelText: 'Password',
                      obscureText: true,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Password is not valid';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 20.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Text('Remember me', style: TextStyle(fontSize: 15)),
                            Checkbox(
                              checkColor: Colors.white,
                              value: _rememberMe,
                              onChanged: (bool? value) {
                                setState(() {
                                  _rememberMe = !_rememberMe;
                                });
                              },
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              'Don\'t have an',
                              style: TextStyle(fontSize: 15),
                            ),
                            TextButton(
                              style: ButtonStyle(
                                splashFactory: NoSplash.splashFactory,
                                padding: WidgetStateProperty.all<EdgeInsets>(EdgeInsets.zero),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => const SignOn()),
                                );
                              },
                              child: const Text('account', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                            ),
                            const Text(
                              '?',
                              style: TextStyle(fontSize: 15),
                            ),
                          ],
                        )
                      ],
                    ),
                    const SizedBox(height: 20.0),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            saveIsAlreadyLogged();
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const HomePage()),
                            );
                          }
                        },
                        child: const Text('Login'),
                      ),
                    ),
                    const SizedBox(height: 30.0),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Divider(
                            thickness: 2,
                          ),
                        ),
                        SizedBox(width: 5),
                        Text('or continue with', style: TextStyle(color: Colors.grey)),
                        SizedBox(width: 5),
                        Expanded(
                          child: Divider(
                            thickness: 2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Material(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(16),
                          child: InkWell(
                            onTap: () {},
                            borderRadius: BorderRadius.circular(16),
                            splashColor: Colors.grey.withValues(alpha: 0.4),
                            child: Container(
                              width: 100,
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey[600]!),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Image.asset(
                                'assets/google.png',
                                height: 40,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Material(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(16),
                          child: InkWell(
                            onTap: () {},
                            borderRadius: BorderRadius.circular(16),
                            splashColor: Colors.grey.withValues(alpha: 0.4),
                            child: Container(
                              width: 100,
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey[600]!),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Image.asset(
                                'assets/apple.png',
                                height: 40,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    ));
  }
}
