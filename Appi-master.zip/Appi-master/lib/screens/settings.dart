import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/hives_card.dart';
import '../widgets/modal.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

List<String> _languages = <String>['Italiano', 'Français', 'English', 'Deutsch', 'Español'];
List<String> _apiaries = <String>['Castelmonte', 'Udine'];

class _SettingsState extends State<Settings> {
  bool _notifications = true;
  final List<DropdownMenuEntry<String>> _languagesMenu = _languages
      .map((String language) => DropdownMenuEntry<String>(
            value: language,
            label: language,
          ))
      .toList();
  final List<DropdownMenuEntry<String>> _apiariesMenu = _apiaries
      .map((String language) => DropdownMenuEntry<String>(
            value: language,
            label: language,
          ))
      .toList();
  String? _selectedLanguage = _languages[2];
  String? _selectedApiary = _apiaries[0];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.only(left: 10, top: 20, right: 10),
        child: ListView(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'General',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                ),
                const SizedBox(
                  height: 10,
                ),
                Card(
                  child: ListTile(
                    leading: const Icon(
                      Icons.account_circle,
                      size: 50,
                    ),
                    title: Row(children: [
                      RichText(
                          text: TextSpan(
                              style: GoogleFonts.aBeeZee(
                                fontSize: 18,
                              ),
                              children: const [
                            TextSpan(
                              text: 'User: ',
                              style: TextStyle(color: Colors.black),
                            ),
                          ])),
                      RichText(
                          text: TextSpan(style: GoogleFonts.aBeeZee(fontSize: 20, fontWeight: FontWeight.bold), children: const [
                        TextSpan(
                          text: 'admin',
                          style: TextStyle(color: Colors.black),
                        ),
                      ])),
                    ]),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          RichText(
                              text: TextSpan(
                                  style: GoogleFonts.aBeeZee(
                                    fontSize: 18,
                                  ),
                                  children: const [
                                TextSpan(
                                  text: 'Apiaries: ',
                                  style: TextStyle(color: Colors.black),
                                ),
                              ])),
                          RichText(
                              text: TextSpan(style: GoogleFonts.aBeeZee(fontSize: 20, fontWeight: FontWeight.bold), children: const [
                            TextSpan(
                              text: '2',
                              style: TextStyle(color: Colors.black),
                            ),
                          ])),
                        ]),
                        Row(children: [
                          RichText(
                              text: TextSpan(
                                  style: GoogleFonts.aBeeZee(
                                    fontSize: 18,
                                  ),
                                  children: const [
                                TextSpan(
                                  text: 'Hives: ',
                                  style: TextStyle(color: Colors.black),
                                ),
                              ])),
                          RichText(
                              text: TextSpan(style: GoogleFonts.aBeeZee(fontSize: 20, fontWeight: FontWeight.bold), children: const [
                            TextSpan(
                              text: '4',
                              style: TextStyle(color: Colors.black),
                            ),
                          ])),
                        ]),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: 'Delete account',
                          onPressed: () {
                            userModal(context, 'You are going to delete your account. All of your data will be lost.', 'Delete');
                          },
                          icon: const Icon(Icons.delete),
                        ),
                        IconButton(
                          tooltip: 'Logout',
                          onPressed: () {
                            userModal(context, 'You are going to disconnect your account.', 'Disconnect');
                          },
                          icon: const Icon(Icons.logout),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20.0),
                Row(
                  children: [
                    const Text('Language', style: TextStyle(fontSize: 18)),
                    const SizedBox(width: 30.0),
                    DropdownMenu(
                      dropdownMenuEntries: _languagesMenu,
                      initialSelection: _selectedLanguage,
                      onSelected: (str) {
                        setState(() {
                          _selectedLanguage = str;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),
                Row(
                  children: [
                    const Text('Push notifications', style: TextStyle(fontSize: 18)),
                    const SizedBox(
                      width: 30,
                    ),
                    Switch(
                      value: _notifications,
                      onChanged: (bool value) {
                        setState(() {
                          _notifications = value;
                        });
                      },
                    )
                  ],
                )
              ],
            ),
            const SizedBox(height: 40.0),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Activity',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                ),
                const SizedBox(
                  height: 10,
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  DropdownMenu(
                    dropdownMenuEntries: _apiariesMenu,
                    initialSelection: _selectedApiary,
                    onSelected: (str) {
                      setState(() {
                        _selectedApiary = str;
                      });
                    },
                  ),
                  Row(
                    children: [
                      FloatingActionButton(
                        onPressed: () {},
                        child: const Icon(
                          Icons.add,
                          size: 30,
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      FloatingActionButton(
                        onPressed: () {
                          apiaryModal(context, 'You are going to delete this apiary. All data about apiary and related hives will be lost', 'Delete');
                        },
                        child: const Icon(
                          Icons.delete,
                          size: 30,
                        ),
                      )
                    ],
                  ),
                ]),
                const SizedBox(
                  height: 30,
                ),
                const SizedBox(
                  height: 10,
                ),
                const HiveCard(id: '1', state: '08', stateDescr: 'Brief state description', lastVisited: '12/12/24'),
                const HiveCard(id: '2', state: '01', stateDescr: 'Brief state description', lastVisited: '18/12/24')
              ],
            ),
          ],
        ),
      ),
    );
  }
}
