import 'package:appi/widgets/pie_chart.dart';
import 'package:flutter/material.dart';
import '../widgets/progress_indicator.dart';

class Community extends StatefulWidget {
  const Community({super.key});

  @override
  State<Community> createState() => _CommunityState();
}

List<String> _areas = <String>['1km', '3km', '5km', '10km', '20km', '50km'];

class _CommunityState extends State<Community> {
  final _formKey = GlobalKey<FormState>();
  final List<DropdownMenuEntry<String>> _areasMenu = _areas
      .map((String area) => DropdownMenuEntry<String>(
            value: area,
            label: area,
          ))
      .toList();
  String? _selectedArea = _areas[0];
  final TextEditingController _areaController = TextEditingController();

  @override
  void dispose() {
    _areaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
          padding: const EdgeInsets.all(10),
          child: ListView(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text(
                'Community',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 10.0),
              Row(
                children: [
                  const Text('Area', style: TextStyle(fontSize: 18)),
                  const SizedBox(width: 50.0),
                  Expanded(
                    child: Form(
                      key: _formKey,
                      child: TextFormField(
                        onTapOutside: (event) {
                          FocusScope.of(context).unfocus();
                        },
                        controller: _areaController,
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText: 'eg. Castelmonte',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  )
                ],
              ),
              const SizedBox(height: 20.0),
              Row(
                children: [
                  const Text('Radius', style: TextStyle(fontSize: 18)),
                  const SizedBox(width: 30.0),
                  DropdownMenu(
                    dropdownMenuEntries: _areasMenu,
                    initialSelection: _selectedArea,
                    onSelected: (str) {
                      setState(() {
                        _selectedArea = str;
                      });
                    },
                  ),
                ],
              ),
              const SizedBox(height: 45.0),
              const Text(
                'States overview',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const MyPieChart(),
              const SizedBox(height: 10.0),
              const Text('In this area: 10 hives - 5 beekeepers', style: TextStyle(fontSize: 18)),
              const SizedBox(height: 40.0),
              const Text(
                'Trends',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 10.0),
              const Text('Treated', style: TextStyle(fontSize: 18),),
              MyProgressIndicator(percentage: '65%', color: Colors.red[200]!),
              const SizedBox(height: 20.0),
              const Text('Feeded', style: TextStyle(fontSize: 18),),
              MyProgressIndicator(percentage: '65%', color: Colors.red[200]!),
              const SizedBox(height: 20.0),
              const Text('Harvested', style: TextStyle(fontSize: 18),),
              MyProgressIndicator(percentage: '85%', color: Colors.green[200]!),
            ])
          ])),
    );
  }
}
