import 'package:appi/utils/utils.dart';
import 'package:flutter/material.dart';
import 'hive_state.dart';

class ApiaryDetails extends StatelessWidget {
  const ApiaryDetails({required this.id, super.key});

  final String id;

  Widget _buildTile(BuildContext context, String leading, String title, String subtitle, String trailing,  Color? stateColor, {isHeader=false}) {
    return isHeader
        ? ListTile(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(leading, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
            Text(title, style: const TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
            Text(subtitle, style: const TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
            Text(trailing,style: const TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
          ],
        )
    )
        : Column(
        children: [Container(
          height: 55,
          color: Colors.green[50],
          child: ListTile(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const HiveState(),
                  ),
                );
              },
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: stateColor,
                          shape: BoxShape.rectangle,
                        ),
                      ),
                      Text(leading),
                    ],
                  ),
                  Text(title, style: const TextStyle(fontSize: 16),),
                  Text(subtitle, style: const TextStyle(fontSize: 16),),
                  Text(trailing,style: const TextStyle(fontSize: 16),),
                ],
              )
          ),
        ), const SizedBox(height: 10),
        ]
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Apiary $id states')),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: ListView(
          children: id == '1' ? [
            const Text(
              'Details',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
            ),
            const SizedBox(height: 5.0),
            _buildTile(context, 'State', 'Date', 'Hive ID', 'Description', Colors.red[600], isHeader: true),
            _buildTile(context, '01', '28/01/25', 'Hive 1', 'State descr.', Colors.green[600]),
            _buildTile(context, '01', '01/02/25', 'Hive 1', 'State descr.', Colors.green[600]),
            _buildTile(context, '01', '02/02/25', 'Hive 2', 'State descr.', Colors.green[600]),
            const SizedBox(height: 40.0),
            const Text(
              'To-dos',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
            ),
            buildToDo('24/01/25', 'Hive 1', 'Treatment'),
            buildToDo('28/01/25', 'Hive 2', 'Harvest'),
          ] :
          [
            const Text(
              'Details',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
            ),
            _buildTile(context, 'State', 'Date', 'Hive ID', 'Description', Colors.red[600], isHeader: true),
            _buildTile(context, '08', '24/01/25', 'Hive 5', 'State descr.', Colors.red[600]),
            _buildTile(context, '08', '27/01/25', 'Hive 3', 'State descr.',Colors.red[600]),
            _buildTile(context, '01', '28/01/25', 'Hive 6', 'State descr.', Colors.green[600]),
            const SizedBox(height: 30.0),
            const Text(
              'To-dos',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
            ),
            buildToDo('24/01/25', 'Hive 6', 'Feed'),
            buildToDo('27/01/25', 'Hive 5', 'Inspection'),
            buildToDo('01/02/25', 'Hive 3', 'Treatment'),
          ])
      ),
    );
  }
}
