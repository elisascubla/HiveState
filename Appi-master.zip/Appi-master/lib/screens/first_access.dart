import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/app_banner.dart';
import 'login.dart';

class FirstAccess extends StatefulWidget {
  const FirstAccess({super.key});

  @override
  State<FirstAccess> createState() => _FirstAccessState();
}

const List<String> languages = <String>['Italiano', 'Français', 'English', 'Deutsch', 'Español'];

//defining type for languages
typedef MenuEntry = DropdownMenuEntry<String>;

class _FirstAccessState extends State<FirstAccess> {
  bool _isFirstLaunch = true;
  int _currentIndex = 2;

  Future<void> saveIsFirstLaunch() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isFirstLaunch', _isFirstLaunch);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(children: [
      const AppBanner(),
      Expanded(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'SELECT LANGUAGE',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 30.0),
              CarouselSlider(
                items: languages.asMap().entries.map((entry) {
                  int index = entry.key;
                  String language = entry.value;

                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 50.0),
                    decoration: BoxDecoration(
                      color: _currentIndex == index ? Colors.green[200] : Colors.grey[300],
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(
                        color: _currentIndex == index ? Colors.green[800]! : Colors.grey,
                        width: 2.0,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        language,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: _currentIndex == index ? Colors.black : Colors.grey[600],
                        ),
                      ),
                    ),
                  );
                }).toList(),
                options: CarouselOptions(
                  scrollDirection: Axis.vertical,
                  enableInfiniteScroll: false,
                  height: 200.0,
                  viewportFraction: 0.3,
                  initialPage: _currentIndex,
                  enlargeCenterPage: true,
                  onPageChanged: (index, reason) {
                    setState(() {
                      _currentIndex = index;
                    });
                  },
                ),
              ),
              const SizedBox(height: 30.0),
              ElevatedButton(
                onPressed: () {
                  _isFirstLaunch = false;
                  saveIsFirstLaunch();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Login()),
                  );
                },
                child: const Text('Get started'),
              ),
            ],
          ),
        ),
      ),
    ]));
  }
}
