import 'package:appi/utils/utils.dart';
import 'package:appi/widgets/bar_chart.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class Apiaries extends StatefulWidget {
  const Apiaries({super.key});

  @override
  State<Apiaries> createState() => _ApiariesState();
}

class _ApiariesState extends State<Apiaries> {
  final CarouselSliderController _controller = CarouselSliderController();
  int _currentIndex = 0;
  final List<String> _titles = ['Apiary 1 - hives by states', 'Apiary 2 - hives by states'];
  final List<Widget> _itemsList = List.generate(
    2,
    (index) => Container(
      margin: const EdgeInsets.all(9),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.green[600],
        borderRadius: BorderRadius.circular(31),
      ),
    ),
  );

  List<BarChartGroupData> _buildChartData(List<double> toY, List<Color> colors) {
    return [
      BarChartGroupData(x: 0, barsSpace: 5, barRods: [
        BarChartRodData(
          fromY: 0,
          toY: toY[0],
          width: 30,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          color: colors[0],
        ),
      ]),
      BarChartGroupData(x: 1, barRods: [
        BarChartRodData(
          fromY: 0,
          toY: toY[1],
          width: 30,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          color: colors[1],
        ),
      ]),
      BarChartGroupData(x: 2, barRods: [
        BarChartRodData(
          fromY: 0,
          toY: toY[2],
          width: 30,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          color: colors[2],
        ),
      ]),
      BarChartGroupData(x: 3, barRods: [
        BarChartRodData(
          fromY: 0,
          toY: toY[3],
          width: 30,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          color: colors[3],
        ),
      ])
    ];
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
          padding: const EdgeInsets.all(10),
          child: ListView(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text(
                'Overview',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 10.0),
              Center(
                  child: Text(
                _titles[_currentIndex],
                style: const TextStyle(fontSize: 18),
              )),
              const SizedBox(height: 20.0),
              CarouselSlider(
                items: [
                  MyBarChart(
                    apiaryId: '1',
                    groupData: _buildChartData([
                      1.5,
                      1.0,
                      0.5,
                      1.0
                    ], [
                      Colors.green[600] ?? Colors.green,
                      Colors.green[600] ?? Colors.green,
                      Colors.red[600] ?? Colors.red,
                      Colors.red[600] ?? Colors.red,
                    ]),
                  ),
                  MyBarChart(
                    apiaryId: '2',
                    groupData: _buildChartData([
                      1,
                      1.4,
                      0.5,
                      0.3
                    ], [
                      Colors.green[600] ?? Colors.green,
                      Colors.green[600] ?? Colors.green,
                      Colors.red[600] ?? Colors.red,
                      Colors.red[600] ?? Colors.red,
                    ]),
                  ),
                ],
                options: CarouselOptions(
                  height: 280,
                  viewportFraction: 1,
                  enlargeCenterPage: false,
                  enableInfiniteScroll: false,
                  onPageChanged: (index, reason) {
                    setState(() {
                      _currentIndex = index;
                    });
                  },
                ),
                carouselController: _controller,
              ),
              const SizedBox(
                height: 10,
              ),
              const Center(child: Text('Number of hives', style: TextStyle(fontSize: 14),)),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  _itemsList.length,
                  (index) => Container(
                    width: 12.0,
                    height: 12.0,
                    margin: const EdgeInsets.symmetric(horizontal: 4.0),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _currentIndex == index ? Colors.green[600] : Colors.grey,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30.0),
              const Text(
                'To-dos',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 10.0),
              buildToDo('24/01/25', 'Hive 1', 'Treatment'),
              buildToDo('24/01/25', 'Hive 6', 'Feed'),
              buildToDo('27/01/25', 'Hive 5', 'Inspection'),
              buildToDo('28/01/25', 'Hive 2', 'Harvest'),
              buildToDo('01/02/25', 'Hive 3', 'Treatment'),
            ]),
          ])),
    );
  }
}
