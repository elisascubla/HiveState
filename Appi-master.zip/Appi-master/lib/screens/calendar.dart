import 'package:appi/utils/utils.dart';
import 'package:appi/widgets/progress_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'forms/add_todo.dart';

class Calendar extends StatelessWidget {
  const Calendar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(left: 10, top: 20, right: 10, bottom: 75),
          child: DefaultTabController(
            length: 2,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'To-dos calendar',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                  ),
                  const SizedBox(height: 10),
                  const TabBar(
                    tabs: [
                      Tab(text: "Month"),
                      Tab(text: "Week"),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    height: 300,
                    child: TabBarView(
                      dragStartBehavior: DragStartBehavior.down,
                      children: [
                        MonthView(),
                        WeekView(),
                      ],
                    ),
                  ),
                  const Text(
                    'Community trend',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                  ),
                  const SizedBox(height: 15),
                  MyProgressIndicator(label: 'Harvest', percentage: '75%', color: Colors.green[200]!),
                  const SizedBox(height: 30),
                  const Text(
                    'Weather forecast',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                  ),
                  const SizedBox(height: 10),
                  CarouselSlider(
                    items: [
                      Column(
                        children: [
                          const Text('Today'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Clear'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('2.0°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('14.0°'),
                            ],
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Tomorrow'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Clouds'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('5.3°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('6.3°'),
                            ],
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Next day'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Rain'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('8.0°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('14.0°'),
                            ],
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Other day'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Snow'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('-1.0°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('2.0°'),
                            ],
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Other day'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Fog'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('2.7°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('8.0°'),
                            ],
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Other day'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Clear'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('7.6°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('14.0°'),
                            ],
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Other day'),
                          const SizedBox(
                            height: 10,
                          ),
                          getWeatherIcon('Clear'),
                          const SizedBox(
                            height: 10,
                          ),
                          const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('10.2°'),
                              SizedBox(
                                width: 20,
                              ),
                              Text('17.6°'),
                            ],
                          )
                        ],
                      ),
                    ],
                    options: CarouselOptions(
                      height: 110,
                      viewportFraction: 0.35,
                      padEnds: false,
                      enlargeCenterPage: false,
                      enableInfiniteScroll: false,
                      onPageChanged: (index, reason) {},
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniEndFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddToDo(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

class WeekView extends StatelessWidget {
  final Map<int, String> days = {22: "Monday 22/1", 23: "Tuesday 23/1", 24: "Wednesday 24/1", 25: "Thursday 25/1", 26: "Friday 26/1", 27: "Saturday 27/1", 28: "Sunday 28/1"};
  final List<int> specialDays = [22, 26, 27];
  final int count = 0;

  WeekView({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 3,
      ),
      itemCount: days.length,
      itemBuilder: (context, index) {
        int dayKey = days.keys.elementAt(index);
        var entries = days.entries.toList();
        bool color = specialDays.contains(dayKey) || dayKey == count;
        return Card(
          color: color ? Colors.grey[350] : Colors.white,
          child: Center(
            child: Text(
              entries[index].value,
            ),
          ),
        );
      },
    );
  }
}

class MonthView extends StatelessWidget {
  final List<int> daysInMonth = List.generate(31, (index) => index + 1);
  final List<int> specialDays = [7, 15, 22, 26, 27];
  final int count = 0;

  MonthView({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        childAspectRatio: 1,
      ),
      itemCount: daysInMonth.length,
      itemBuilder: (context, index) {
        bool color = specialDays.contains(daysInMonth[index]) || index == count;
        return Card(
          color: color ? Colors.grey[350] : Colors.white,
          child: Center(
            child: Text(
              "${daysInMonth[index]}",
            ),
          ),
        );
      },
    );
  }
}
