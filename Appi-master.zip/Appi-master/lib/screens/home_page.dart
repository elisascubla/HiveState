import 'package:flutter/material.dart';
import 'apiaries.dart';
import 'community.dart';
import 'calendar.dart';
import 'settings.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Widget> _pages = [const Apiaries(), const Community(), const Calendar(), const Settings()];
  int _currentPageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: _pages[_currentPageIndex],
        bottomNavigationBar: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          child: NavigationBar(
            onDestinationSelected: (int index) {
              setState(() {
                _currentPageIndex = index;
              });
            },
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            selectedIndex: _currentPageIndex,
            destinations: <Widget>[
              const NavigationDestination(
                selectedIcon: Icon(Icons.home),
                icon: Icon(Icons.home),
                label: 'Apiaries',
              ),
              NavigationDestination(
                icon: _currentPageIndex != 1 ? const Badge(child: Icon(Icons.group)) : const Icon(Icons.group),
                label: 'Community',
              ),
              const NavigationDestination(
                icon: Icon(Icons.calendar_month),
                label: 'Tasks',
              ),
              const NavigationDestination(
                icon: Icon(Icons.settings),
                label: 'Settings',
              ),
            ],
          ),
        ),
    );
  }
}
