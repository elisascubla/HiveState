import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AddToDo extends StatefulWidget {
  const AddToDo({super.key});

  @override
  State<AddToDo> createState() => _AddToDoState();
}

final List<String> _apiaries = <String>['Castelmonte', 'Udine'];
final List<String> _hives = <String>['1', '2'];
final List<String> _todo = <String>['Inspection', 'Harvest', 'Feed', 'Treatment', 'Winterize', 'Requeen'];

class _AddToDoState extends State<AddToDo> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  final List<DropdownMenuEntry<String>> _apiariesMenu = _apiaries
      .map((String apiary) => DropdownMenuEntry<String>(
            value: apiary,
            label: apiary,
          ))
      .toList();
  String? _selectedApiary = _apiaries[0];
  final List<DropdownMenuEntry<String>> _hivesMenu = _hives
      .map((String hive) => DropdownMenuEntry<String>(
            value: hive,
            label: hive,
          ))
      .toList();
  String? _selectedHive = _hives[0];
  final List<DropdownMenuEntry<String>> _todoMenu = _todo
      .map((String todo) => DropdownMenuEntry<String>(
            value: todo,
            label: todo,
          ))
      .toList();
  String? _selectedTodo = _todo[0];
  bool notifyMe = true;

  Future<void> _selectDate(BuildContext context) async {
    final now = DateTime.now();
    final end = DateTime(now.year, now.month + 1, now.day);
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: end,
    );
    if (pickedDate != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      if (pickedTime != null) {
        final DateTime fullDateTime = DateTime(
          pickedDate.year,
          pickedDate.month,
          pickedDate.day,
          pickedTime.hour,
          pickedTime.minute,
        );
        setState(() {
          _dateController.text = DateFormat('dd/MM/yyyy hh:mm a').format(fullDateTime);
        });
      }
    }
  }

  String toFormat(DateTime date) {
    String formattedDate = DateFormat('dd/MM/yyyy hh:mm a').format(date);
    return formattedDate;
  }

  @override
  void dispose() {
    _dateController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add To-do'),
        actions: [
          TextButton(
            child: const Text('Submit'),
            onPressed: () {
              FocusScope.of(context).unfocus();
              if (_formKey.currentState!.validate()) {
                Navigator.pop(
                  context,
                );
              }
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 10, top: 20, right: 10, bottom: 10),
        child: Column(
          children: [
            Expanded(
              child: Form(
                key: _formKey,
                child: Stack(children: [
                  ListView(children: [
                    TextFormField(
                      onTapOutside: (event) {
                        FocusScope.of(context).unfocus();
                      },
                      controller: _dateController,
                      decoration: const InputDecoration(
                        labelText: 'Select Date',
                        suffixIcon: Icon(Icons.calendar_today),
                        border: OutlineInputBorder(),
                      ),
                      readOnly: true,
                      onTap: () => _selectDate(context),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            const Text('Apiary', style: TextStyle(fontSize: 18)),
                            DropdownMenu(
                              dropdownMenuEntries: _apiariesMenu,
                              initialSelection: _selectedApiary,
                              onSelected: (str) {
                                setState(() {
                                  _selectedApiary = str;
                                });
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            const Text('Hive', style: TextStyle(fontSize: 18)),
                            DropdownMenu(
                              dropdownMenuEntries: _hivesMenu,
                              initialSelection: _selectedHive,
                              onSelected: (str) {
                                setState(() {
                                  _selectedHive = str;
                                });
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: Colors.transparent,
                                border: Border.all(
                                  color: Colors.red[200]!,
                                  width: 3.0,
                                ),
                              ),
                              child: const Padding(
                                padding: EdgeInsets.all(10),
                                child: Column(
                                  children: [
                                    Center(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text('08', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                                          SizedBox(
                                            width: 20,
                                          ),
                                          Text('Brief state description', style: TextStyle(fontSize: 18)),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            const Text('To-do', style: TextStyle(fontSize: 18)),
                            DropdownMenu(
                              dropdownMenuEntries: _todoMenu,
                              initialSelection: _selectedTodo,
                              onSelected: (str) {
                                setState(() {
                                  _selectedTodo = str;
                                });
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        const Divider(
                          thickness: 2,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 20.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            const Text('Notify me 1 day before', style: TextStyle(fontSize: 18)),
                            Switch(
                                value: notifyMe,
                                onChanged: (bool val) {
                                  setState(() {
                                    notifyMe = !notifyMe;
                                  });
                                })
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        TextFormField(
                          onTapOutside: (event) {
                            FocusScope.of(context).unfocus();
                          },
                          maxLines: 5,
                          controller: _notesController,
                          decoration: const InputDecoration(
                            labelText: 'Notes',
                            hintText: 'Type something',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ],
                    )
                  ]),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
