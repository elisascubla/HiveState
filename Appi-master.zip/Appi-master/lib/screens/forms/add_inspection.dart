import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../review.dart';

class AddInspection extends StatefulWidget {
  const AddInspection({super.key});

  @override
  State<AddInspection> createState() => _AddInspectionState();
}

final List<String> _weather = <String>['Sunny', 'Cloudy', 'Rain', 'Snow', 'Fog'];
final List<String> _temperment = <String>['Calm', 'Aggressive', 'Nervous'];

class _AddInspectionState extends State<AddInspection> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _dateController = TextEditingController();
  final List<DropdownMenuEntry<String>> _weatherMenu = _weather
      .map((String weather) => DropdownMenuEntry<String>(
            value: weather,
            label: weather,
          ))
      .toList();
  String? _selectedWeather = _weather[0];
  final List<DropdownMenuEntry<String>> _tempermentMenu = _temperment
      .map((String temperment) => DropdownMenuEntry<String>(
            value: temperment,
            label: temperment,
          ))
      .toList();
  String? _selectedTemperment = _temperment[0];
  final TextEditingController _temperatureController = TextEditingController();
  final TextEditingController _supersController = TextEditingController();
  final TextEditingController _framesController = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1);
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: startOfMonth,
      lastDate: now,
    );
    if (pickedDate != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      if (pickedTime != null) {
        final DateTime fullDateTime = DateTime(
          pickedDate.year,
          pickedDate.month,
          pickedDate.day,
          pickedTime.hour,
          pickedTime.minute,
        );
        setState(() {
          _dateController.text = DateFormat('dd/MM/yyyy hh:mm a').format(fullDateTime);
        });
      }
    }
  }

  String toFormat(DateTime date) {
    String formattedDate = DateFormat('dd/MM/yyyy hh:mm a').format(date);
    return formattedDate;
  }

  @override
  void dispose() {
    _dateController.dispose();
    _temperatureController.dispose();
    _supersController.dispose();
    _framesController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _dateController.text = toFormat(DateTime.now());
    _temperatureController.text = '8.4';
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Inspection'),
        actions: [
          TextButton(
            child: const Text('Next'),
            onPressed: () {
              FocusScope.of(context).unfocus();
              if (_formKey.currentState!.validate()) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Review()),
                );
              }
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 10, top: 20, right: 10, bottom: 10),
        child: Column(
          children: [
            Expanded(
              child: Form(
                key: _formKey,
                child: Stack(children: [
                  ListView(children: [
                    const Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(children: [
                          Text('Apiary: ', style: TextStyle(fontSize: 20)),
                          Text('Castelmonte', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        ]),
                        Row(children: [
                          Text('Hive: ', style: TextStyle(fontSize: 20)),
                          Text('1', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        ])
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    TextFormField(
                      onTapOutside: (event) {
                        FocusScope.of(context).unfocus();
                      },
                      controller: _dateController,
                      decoration: const InputDecoration(
                        labelText: 'Date',
                        suffixIcon: Icon(Icons.calendar_today),
                        border: OutlineInputBorder(),
                      ),
                      readOnly: true,
                      onTap: () => _selectDate(context),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        const SizedBox(height: 20.0),
                        const Divider(
                          thickness: 2,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 20.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            DropdownMenu(
                              label: const Text('Weather'),
                              dropdownMenuEntries: _weatherMenu,
                              initialSelection: _selectedWeather,
                              onSelected: (str) {
                                setState(() {
                                  _selectedWeather = str;
                                });
                              },
                            ),
                            const SizedBox(width: 20.0),
                            Expanded(
                              child: TextFormField(
                                onTapOutside: (event) {
                                  FocusScope.of(context).unfocus();
                                },
                                decoration: const InputDecoration(
                                  suffixIcon: Icon(Icons.edit),
                                  labelText: 'Temperature(°C)',
                                  border: OutlineInputBorder(),
                                ),
                                keyboardType: TextInputType.number,
                                controller: _temperatureController,
                              ),
                            )
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        const Divider(
                          thickness: 2,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 20.0),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                onTapOutside: (event) {
                                  FocusScope.of(context).unfocus();
                                },
                                decoration: const InputDecoration(
                                  helperText: '*required',
                                  labelText: 'Supers',
                                  border: OutlineInputBorder(),
                                ),
                                keyboardType: TextInputType.number,
                                controller: _supersController,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please insert supers';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            const SizedBox(width: 30.0),
                            Expanded(
                              child: TextFormField(
                                onTapOutside: (event) {
                                  FocusScope.of(context).unfocus();
                                },
                                decoration: const InputDecoration(
                                  helperText: '*required',
                                  labelText: 'Frames',
                                  border: OutlineInputBorder(),
                                ),
                                keyboardType: TextInputType.number,
                                controller: _framesController,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please insert frames';
                                  }
                                  return null;
                                },
                              ),
                            )
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        Center(
                          child: DropdownMenu(
                            label: const Text('Temperment'),
                            dropdownMenuEntries: _tempermentMenu,
                            initialSelection: _selectedTemperment,
                            onSelected: (str) {
                              setState(() {
                                _selectedTemperment = str;
                              });
                            },
                          ),
                        ),
                      ],
                    )
                  ]),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
