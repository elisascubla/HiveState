import 'package:appi/screens/hive_state.dart';
import 'package:appi/widgets/inspection_detail.dart';
import 'package:appi/widgets/rating_star.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/review_card.dart';
import 'notes.dart';

Color? _getColor(double rating) {
  if (rating > 0 && rating <= 2) {
    return Colors.red;
  } else if (rating > 2 && rating <= 3) {
    return Colors.yellow[600];
  } else {
    return Colors.green;
  }
}

class Review extends StatefulWidget {
  const Review({super.key});

  @override
  State<Review> createState() => _ReviewState();
}

final List<String> _titles = ['Hive population', 'Food stores', 'Queen and brood', 'Bee stressors', 'Feedback on predicted state', 'Inspection summary'];
final List<String> _probs = ['Varroa mites', 'Chalkbrood', 'Mice', 'Sacbrood', 'USA foulbrood', 'Ants', 'Eu. foulbrood', 'Nosema', 'Beetles', 'Moths', 'Wasps', 'Hornets'];

class _ReviewState extends State<Review> {
  int _currentIndex = 0;
  final List<bool> _isSelected = List.generate(_probs.length, (index) => false);
  bool _queenSeen = true;
  bool _broodStage = true;
  bool _queenCells = false;
  double _hivePopRating = 3.0;
  double _foodStoresRating = 3.0;
  double _feedbackRating = 3.0;

  List<Widget> _buildItemsList(BuildContext context) {
    return [
      ReviewCard(
          question: 'How would you evaluate the population of your hive?',
          body: MyRatingStar(
            color: _getColor(_hivePopRating)!,
            rating: _hivePopRating,
            onRatingChanged: (newRating) {
              setState(() {
                _hivePopRating = newRating;
              });
            },
          ),
          actions: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Notes()),
                    );
                  },
                  child: const Text('Add Notes')),
              TextButton(onPressed: () {}, child: const Text('Help')),
            ],
          )),
      ReviewCard(
          question: 'How would you evaluate the honey and pollen stores?',
          body: MyRatingStar(
            color: _getColor(_foodStoresRating)!,
            rating: _foodStoresRating,
            onRatingChanged: (newRating) {
              setState(() {
                _foodStoresRating = newRating;
              });
            },
          ),
          actions: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Notes()),
                    );
                  },
                  child: const Text('Add Notes')),
              TextButton(onPressed: () {}, child: const Text('Help')),
            ],
          )),
      ReviewCard(
          question: 'How would you evaluate the population of your hive?',
          body: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'All brood stages are present',
                    style: TextStyle(fontSize: 18),
                  ),
                  Checkbox(
                    value: _broodStage,
                    onChanged: (bool? value) {
                      setState(() {
                        _broodStage = value!;
                      });
                    },
                  )
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Queen seen',
                    style: TextStyle(fontSize: 18),
                  ),
                  Checkbox(
                    value: _queenSeen,
                    onChanged: (bool? value) {
                      setState(() {
                        _queenSeen = value!;
                      });
                    },
                  )
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Queen cells',
                    style: TextStyle(fontSize: 18),
                  ),
                  Checkbox(
                    value: _queenCells,
                    onChanged: (bool? value) {
                      setState(() {
                        _queenCells = value!;
                      });
                    },
                  )
                ],
              )
            ],
          ),
          actions: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Notes()),
                    );
                  },
                  child: const Text('Add Notes')),
              TextButton(onPressed: () {}, child: const Text('Help')),
            ],
          )),
      ReviewCard(
          question: '',
          body: Column(
            children: [
              _buildFilterChips(),
            ],
          ),
          actions: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Notes()),
                    );
                  },
                  child: const Text('Add Notes')),
              TextButton(onPressed: () {}, child: const Text('Help')),
            ],
          )),
      ReviewCard(
          question: 'How precise would you evaluate the predicted state?',
          body: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.red[600]!,
                    width: 3.0,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: RichText(
                  text: TextSpan(
                    style: GoogleFonts.aBeeZee(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    children: const [
                      TextSpan(
                        text: '08 - ',
                        style: TextStyle(color: Colors.black),
                      ),
                      TextSpan(
                        text: 'Brief state description',
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              MyRatingStar(
                color: _getColor(_feedbackRating)!,
                rating: _feedbackRating,
                onRatingChanged: (newRating) {
                  setState(() {
                    _feedbackRating = newRating;
                  });
                },
              ),
            ],
          ),
          actions: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Notes()),
                    );
                  },
                  child: const Text('Add Notes')),
              TextButton(onPressed: () {}, child: const Text('Help')),
            ],
          )),
      ReviewCard(
          question: '',
          body: Column(
            children: [
              const Text('07/01/2025 - 8.4°C', style: TextStyle(fontSize: 18)),
              const SizedBox(height: 20.0),
              InspectionDetail(
                  title: const ['Hive population', 'Food stores', 'Queen and brood', 'Bee stressors', 'Feedback', 'Temperment'],
                  color: [Colors.green[200]!, Colors.green[200]!, Colors.yellow[300]!, Colors.red[200]!, Colors.green[200]!, Colors.green[200]!],
                  stars: const [3.0, 3.0, 2.0, 1.0, 4.0]),
            ],
          ),
          actions: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Notes()),
                    );
                  },
                  child: const Text('Add Notes')),
            ],
          )),
    ];
  }

  Widget _buildFilterChips() {
    return Wrap(
      spacing: 8.0,
      runSpacing: 8.0,
      children: List.generate(_probs.length, (index) {
        return GestureDetector(
          onTap: () {
            setState(() {
              _isSelected[index] = !_isSelected[index];
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
            decoration: BoxDecoration(
              color: _isSelected[index] ? Colors.red : Colors.grey,
              borderRadius: BorderRadius.circular(20.0),
            ),
            child: Text(
              _probs[index],
              style: const TextStyle(fontSize: 15, color: Colors.white),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: const Text('Review'),
            actions: _currentIndex == 5
                ? [
                    TextButton(
                        onPressed: () {
                          if (_currentIndex == 5) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const HiveState()),
                            );
                          }
                        },
                        child: const Text('Submit'))
                  ]
                : null),
        body: SingleChildScrollView(
          child: Padding(
            // ignore: prefer_const_constructors
            padding: EdgeInsets.only(top: 50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  _titles[_currentIndex],
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: CarouselSlider(
                    items: _buildItemsList(context),
                    options: CarouselOptions(
                      height: 500,
                      viewportFraction: 1,
                      enlargeCenterPage: false,
                      enableInfiniteScroll: false,
                      onPageChanged: (index, reason) {
                        setState(() {
                          _currentIndex = index;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    6,
                    (index) => Container(
                      width: 12.0,
                      height: 12.0,
                      margin: const EdgeInsets.symmetric(horizontal: 4.0),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentIndex == index ? Colors.green[600] : Colors.grey,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}
