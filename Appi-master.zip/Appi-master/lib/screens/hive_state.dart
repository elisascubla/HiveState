import 'package:appi/widgets/inspection_detail.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'forms/add_inspection.dart';

class HiveState extends StatelessWidget {
  const HiveState({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hive 1 state details')),
      body: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 75),
        child: ListView(children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: Colors.transparent,
              border: Border.all(
                color: Colors.red[200]!,
                width: 3.0,
              ),
            ),
            child: const Column(
              children: [
                SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('08', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    SizedBox(
                      width: 20,
                    ),
                    Text('State extended description', style: TextStyle(fontSize: 18)),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Text('Recommended actions', style: TextStyle(fontSize: 18)),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          const Text(
            'Real time info (alert sensor only)',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              _buildExp(
                  'Temperature 34.6°',
                  '8',
                  LineChartBarData(
                    color: Colors.black,
                    spots: [
                      const FlSpot(1, 20),
                      const FlSpot(15, 22),
                      const FlSpot(30, 34.6),
                    ],
                  ),
                  '°'),
              const SizedBox(
                width: 10,
              ),
              _buildExp(
                  'Humidity 75%',
                  '3',
                  LineChartBarData(
                    color: Colors.black,
                    spots: [
                      const FlSpot(1, 65),
                      const FlSpot(15, 55),
                      const FlSpot(30, 75),
                    ],
                  ),
                  '%'),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          const Text(
            'Last Inspection Detail',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          const SizedBox(
            height: 10,
          ),
          InspectionDetail(
              title: const ['Hive population', 'Food stores', 'Queen and brood', 'Bee stressors', 'Feedback', 'Temperment'],
              color: [Colors.green[200]!, Colors.yellow[300]!, Colors.red[200]!, Colors.red[200]!, Colors.green[200]!, Colors.green[200]!],
              stars: const [4.0, 3.0, 2.0, 1.0, 4.0]),
        ]),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniEndFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const AddInspection(),
                          ),
                        );
                      },
                      child: const Text('Inspection'),
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text('Harvest'),
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text('Feed'),
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text('Treat'),
                    ),
                  ],
                ),
              );
            },
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

_buildExp(String txt, String color, LineChartBarData spots, String symbol) {
  return Expanded(
      child: Container(
    decoration: BoxDecoration(
      shape: BoxShape.rectangle,
      color: Colors.transparent,
      border: Border.all(
        color: symbol == '°' ? Colors.red[200]! : Colors.yellow[300]!,
        width: 3.0,
      ),
    ),
    child: Column(
      children: [
        Stack(
          children: [
            Container(
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                color: symbol == '°' ? Colors.red[200]! : Colors.yellow[300]!,
              ),
              alignment: Alignment.topCenter,
              child: Text(
                txt,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10, right: 20),
          child: SizedBox(
            height: 100,
            child: LineChart(LineChartData(
              borderData: FlBorderData(
                show: true,
                border: const Border(
                  left: BorderSide(color: Colors.black, width: 1),
                  bottom: BorderSide(color: Colors.black, width: 1),
                  top: BorderSide.none,
                  right: BorderSide.none,
                ),
              ),
              lineTouchData: LineTouchData(
                touchTooltipData: LineTouchTooltipData(
                  tooltipRoundedRadius: 8,
                  getTooltipItems: (touchedSpots) {
                    return touchedSpots.map((spot) {
                      return symbol == '%' ?
                      LineTooltipItem(
                        '${spot.y.toStringAsFixed(0)}$symbol',
                        const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ) : LineTooltipItem(
                        '${spot.y.toStringAsFixed(1)}$symbol',
                        const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      );
                    }).toList();
                  },
                ),
              ),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    reservedSize: 5,
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      return Text(
                        '${value.toInt()}',
                        style: const TextStyle(fontSize: 1),
                      );
                    },
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    interval: 15,
                    reservedSize: 20,
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      return Text(
                        '${value.toInt()}/1',
                        style: const TextStyle(fontSize: 12),
                      );
                    },
                  ),
                ),
              ),
              gridData: const FlGridData(show: false),
              lineBarsData: [spots],
            )),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        const Text(
          'Updated 2hrs ago',
          style: TextStyle(fontSize: 14),
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    ),
  ));
}
