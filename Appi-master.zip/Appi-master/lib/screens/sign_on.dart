import 'package:flutter/material.dart';
import '../widgets/app_banner.dart';
import '../widgets/text_input_field.dart';

class SignOn extends StatefulWidget {
  const SignOn({super.key});

  @override
  State<SignOn> createState() => _SignOnState();
}

class _SignOnState extends State<SignOn> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const AppBanner(),
          const SizedBox(height: 30.0),
          const Text(
            'CREATE ACCOUNT',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
          ),
          Expanded(
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                children: [
                  const SizedBox(height: 30.0),
                  TextInputField(
                    controller: _usernameController,
                    icon: const Icon(Icons.person),
                    labelText: 'Username',
                    hintText: 'admin',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a username';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 30.0),
                  TextInputField(
                    controller: _emailController,
                    icon: const Icon(Icons.mail),
                    labelText: 'E-mail',
                    hintText: 'admin@example.com',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter an e-mail address';
                      }
                      final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
                      if (!emailRegex.hasMatch(value)) {
                        return 'Please enter a valid e-mail address';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 30.0),
                  TextInputField(
                    controller: _passwordController,
                    icon: const Icon(Icons.lock),
                    labelText: 'Password',
                    hintText: 'at least 6 characters',
                    obscureText: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a password';
                      }
                      if (value.length < 6) {
                        return 'Password must be at least 6 characters long';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 50.0),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          Navigator.pop(context);
                        }
                      },
                      child: const Text('Sign on'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
